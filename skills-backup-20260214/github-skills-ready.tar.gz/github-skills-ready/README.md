# Oskris Web Development Skills

Professional AI Skills for web development and e-commerce projects in Malaysia.

## 📦 Installation

```bash
# Install all skills
npx skills add krisliong1/skills

# Install specific skill
npx skills add krisliong1/skills/requirement-analysis
npx skills add krisliong1/skills/product-listing
```

## 🎯 Available Skills

### 1. core-work-rules
System-wide working principles and trigger keywords.

```bash
npx skills add krisliong1/skills/core-work-rules
```

### 2. requirement-analysis  
Professional requirements gathering for web projects.

```bash
npx skills add krisliong1/skills/requirement-analysis
```

### 3. design-consultant
Web design consultation and proposal creation.

```bash
npx skills add krisliong1/skills/design-consultant
```

### 4. frontend-builder
Professional frontend development implementation.

```bash
npx skills add krisliong1/skills/frontend-builder
```

### 5. project-workflow
Complete project management from lead to delivery.

```bash
npx skills add krisliong1/skills/project-workflow
```

### 6. product-listing
E-commerce product listing creation and optimization.

```bash
npx skills add krisliong1/skills/product-listing
```

## 🇲🇾 Malaysian Focus

All skills are optimized for Malaysian market:
- Local payment methods (FPX, Boost, TNG)
- Local shipping (Ninja Van, J&T, Pos Laju)
- Multi-language support (EN/BM/中文)
- RM currency
- Cultural considerations

## 📖 Documentation

Each skill contains comprehensive documentation in its `SKILL.md` file.

## 🚀 Quick Start

1. Install the skills you need
2. Start using them in your AI agent (Claude Code, Cursor, etc.)
3. Skills automatically activate based on your queries

## 💼 Business Use

Perfect for:
- Web development agencies
- Freelance developers
- E-commerce businesses
- Malaysian SMEs

## 📝 License

See individual skill LICENSE.txt files for details.

## 🤝 Contributing

These skills are maintained for Oskris Web Development.

## 📧 Contact

- Website: https://oskris.com
- GitHub: https://github.com/krisliong1
- Email: official@oskris.com

---

**Created with ❤️ for Malaysian web developers**
