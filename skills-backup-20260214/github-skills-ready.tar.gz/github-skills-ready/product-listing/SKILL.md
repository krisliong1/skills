---
name: product-listing
description: Create professional product listings for e-commerce websites. Use when adding products to online stores, writing product descriptions, optimizing for SEO, or creating product catalogs. Supports WooCommerce, Shopify, and custom platforms.
---

# Product Listing Skill

This skill helps you create professional, SEO-optimized product listings for e-commerce platforms.

## When to Use This Skill

- Adding new products to online stores
- Writing product descriptions
- Creating product catalogs
- Optimizing existing listings
- Bulk product uploads
- Product data migration

## Supported Platforms

- WooCommerce (WordPress)
- Shopify
- Custom e-commerce platforms
- CSV/Excel product imports

## Product Listing Template

### Complete Product Information:

```markdown
# Product Name Guidelines
- Clear, descriptive name
- Include key features/specifications
- Brand name (if applicable)
- Model number (if applicable)

Example: "Samsung 55-inch 4K Smart TV (Model: UN55TU8000)"

# Product Description Structure

## Short Description (100-150 characters)
Brief, compelling summary for product cards and search results.

## Long Description (300-500 words)
1. **Opening Hook** - Key benefit or unique selling point
2. **Features & Benefits** - What it does and why it matters
3. **Specifications** - Technical details
4. **Use Cases** - Who it's for and how to use it
5. **Call to Action** - Encourage purchase

## Key Features (Bullet Points)
- Feature 1 with benefit
- Feature 2 with benefit
- Feature 3 with benefit
- Feature 4 with benefit
- Feature 5 with benefit

## Specifications Table
| Specification | Detail |
|---------------|--------|
| Brand | |
| Model | |
| Dimensions | |
| Weight | |
| Color Options | |
| Material | |
| Warranty | |

## Additional Information
- SKU: Product code
- Categories: Main category > Subcategory
- Tags: Keyword1, Keyword2, Keyword3
- Stock Status: In Stock / Out of Stock / Pre-order
```

---

## Malaysian E-commerce Optimization

### Language Considerations:
```
English (Primary): Full detailed description
Bahasa Malaysia: Key features translated
Chinese: Product name + key specs (optional)
```

### Pricing Format:
```
Display: RM 149.00
Compare at price: RM 199.00 (if on sale)
Tax: Include/Exclude GST notation
```

### Shipping Information:
```
- Free shipping: RM 50+ orders
- Delivery areas: West Malaysia / East Malaysia
- Estimated delivery: 2-5 working days
- Shipping partners: J&T, Ninja Van, Pos Laju
```

### Payment Methods Display:
```
Accepted:
- FPX Online Banking
- Credit/Debit Cards
- Boost / TNG / GrabPay
- PayPal
```

---

## SEO Optimization

### Product Title SEO:
```
Format: [Brand] [Product Type] [Key Feature] [Specification] [Model]

Example: 
"Apple iPhone 15 Pro Max 256GB 5G Smartphone - Space Black"

Best Practices:
- Keep under 60 characters
- Include primary keyword
- Add brand name
- Include key specs
- Avoid keyword stuffing
```

### Meta Description:
```
Format: [Action] + [Product] + [Benefit] + [Offer/CTA]

Example:
"Shop Apple iPhone 15 Pro Max 256GB in Malaysia. Free shipping, 
1-year warranty, genuine Apple products. Order now!"

Best Practices:
- 150-160 characters
- Include location (Malaysia)
- Add value proposition
- Include call-to-action
```

### URL Slug:
```
Good: /product/apple-iphone-15-pro-max-256gb-black
Bad: /product/12345
Bad: /product/apple-iphone-15-pro-max-256gb-space-black-5g-smartphone-with-titanium-design
```

### Image SEO:
```
Filename: apple-iphone-15-pro-max-black.jpg
Alt Text: "Apple iPhone 15 Pro Max 256GB in Space Black color"
```

---

## Product Categories Structure

### Example for Gaming Store:
```
Digital Games
├── PC Games
│   ├── Steam Keys
│   ├── Epic Games
│   └── Origin
├── Console Games
│   ├── PlayStation
│   ├── Xbox
│   └── Nintendo Switch
└── Mobile Games
    ├── Game Credits
    └── In-Game Currency

Gaming Accessories
├── Controllers
├── Headsets
├── Keyboards & Mice
└── Streaming Equipment

Game Cards & Credits
├── Steam Wallet
├── PlayStation Network
├── Xbox Live
└── Nintendo eShop
```

### Example for Mac Products:
```
Mac Computers
├── MacBook Air
├── MacBook Pro
├── iMac
├── Mac mini
└── Mac Studio

Mac Accessories
├── Keyboards & Mice
├── Monitors & Displays
├── Adapters & Hubs
├── Storage & Memory
└── Cases & Sleeves

Mac Software
├── Adobe Creative Cloud
├── Microsoft Office
├── Final Cut Pro
└── Logic Pro
```

---

## Product Attributes & Variations

### Setting up Variations:

**For Physical Products:**
```
Variable Product: T-Shirt

Attributes:
1. Size: S, M, L, XL, XXL
2. Color: Red, Blue, Black, White

Variations:
- Red/S - SKU: TSHIRT-RED-S - Price: RM 49
- Red/M - SKU: TSHIRT-RED-M - Price: RM 49
- Blue/L - SKU: TSHIRT-BLUE-L - Price: RM 49
(etc.)

Stock Management:
- Track inventory per variation
- Set low stock threshold
- Enable backorders (optional)
```

**For Digital Products:**
```
Variable Product: Game License

Attributes:
1. Platform: Steam, Epic, Origin
2. Region: Global, EU, US, Asia

Variations:
- Steam/Global - Instant delivery
- Epic/Asia - Instant delivery
(etc.)

No shipping required
Auto-delivery system
```

---

## Product Images Guidelines

### Image Requirements:

**Minimum:**
- 1 primary product image (front view)
- 800 x 800 pixels minimum
- White or transparent background
- JPEG or PNG format

**Recommended:**
- 4-6 images showing different angles
- 1200 x 1200 pixels for zoom feature
- Lifestyle images (product in use)
- Infographic showing features
- Product dimensions diagram

**Image Optimization:**
```
1. Resize to appropriate dimensions
2. Compress for web (aim for <200KB per image)
3. Use descriptive filenames
4. Add alt text for SEO
5. Enable lazy loading
```

### Image Order:
```
1. Main product image (front/default view)
2. Product in packaging
3. Product from different angles
4. Product in use (lifestyle shot)
5. Close-up of key features
6. Size/scale comparison
7. Product variations (if applicable)
```

---

## Product Description Templates

### Template 1: Electronics

```markdown
## [Product Name]

Experience [key benefit] with the [Product Name]. Designed for 
[target audience], this [product type] delivers [main feature] 
in a [design characteristic] package.

### What Makes It Special

Featuring [standout feature], the [Product Name] offers 
[performance metric] that's perfect for [use case]. Whether 
you're [activity 1] or [activity 2], this device ensures 
[benefit].

### Key Features:
- **[Feature 1]**: [Explanation and benefit]
- **[Feature 2]**: [Explanation and benefit]
- **[Feature 3]**: [Explanation and benefit]
- **[Feature 4]**: [Explanation and benefit]

### Technical Specifications

[Specifications table]

### In the Box
- 1x [Product Name]
- 1x [Accessory 1]
- 1x [Accessory 2]
- User manual
- Warranty card

### Why Buy From Us?
✅ Genuine [Brand] product
✅ 1-year manufacturer warranty
✅ Free shipping (orders RM 50+)
✅ Secure payment options
✅ Fast delivery (2-5 days)
```

### Template 2: Digital Products (Game Keys)

```markdown
## [Game Title] - [Platform] Key

**Instant Digital Delivery** | **Global/Region Activation**

### About This Game

[Brief game description - 2-3 sentences]

### Game Features:
- [Feature 1]
- [Feature 2]
- [Feature 3]

### System Requirements

**Minimum:**
- OS: [Operating System]
- Processor: [CPU]
- Memory: [RAM]
- Graphics: [GPU]
- Storage: [HDD/SSD space]

**Recommended:**
- OS: [Operating System]
- Processor: [CPU]
- Memory: [RAM]
- Graphics: [GPU]
- Storage: [HDD/SSD space]

### How to Activate:
1. Purchase and receive key via email (instant)
2. Open [Platform] client
3. Click "Activate a Product"
4. Enter your key
5. Download and play!

### Important Notes:
⚠️ This is a digital product - no physical item will be shipped
⚠️ Keys are region-locked to [Region] - check compatibility
⚠️ Keys are non-refundable once revealed
✅ Instant delivery to your email
✅ 24/7 customer support
```

### Template 3: Physical Products (General)

```markdown
## [Product Name]

[Compelling opening sentence about main benefit]

### Description

[2-3 paragraphs about the product, its uses, and benefits]

### Why Choose [Product Name]?

**Quality:** [Material/build quality details]
**Functionality:** [How it works/what it does]
**Design:** [Aesthetic/ergonomic features]
**Value:** [Why it's worth the price]

### Perfect For:
- [Use case 1]
- [Use case 2]
- [Use case 3]

### What's Included:
- [Item 1]
- [Item 2]
- [Item 3]

### Care Instructions:
[How to maintain/clean/store the product]

### Shipping & Returns:
- Free shipping on orders over RM 50
- Delivery within 2-5 working days
- 7-day return policy (conditions apply)
- Full manufacturer warranty
```

---

## Bulk Product Upload

### CSV Format for WooCommerce:

```csv
SKU,Name,Published,Categories,Tags,Short Description,Description,Price,Sale Price,Stock,Images
PROD001,"Product Name","1","Category > Subcategory","tag1,tag2","Short desc","Long description","149.00","129.00","100","image1.jpg|image2.jpg"
```

### Required Fields:
- SKU (unique identifier)
- Name
- Regular Price
- Stock Quantity

### Recommended Fields:
- Short Description
- Long Description
- Categories
- Tags
- Images (multiple)
- Weight/Dimensions (for shipping)

---

## Product Listing Checklist

Before publishing, ensure:

**Content:**
- [ ] Product name is clear and descriptive
- [ ] Short description is compelling (< 150 chars)
- [ ] Long description is detailed (300-500 words)
- [ ] Key features listed (5-8 bullet points)
- [ ] Specifications complete
- [ ] SEO optimized (title, meta, URL)

**Images:**
- [ ] Minimum 1 high-quality image
- [ ] Recommended 4-6 images
- [ ] Images optimized for web
- [ ] Alt text added
- [ ] Correct image order

**Pricing:**
- [ ] Regular price set
- [ ] Sale price (if applicable)
- [ ] Tax settings correct
- [ ] Currency displayed (RM)

**Inventory:**
- [ ] SKU assigned
- [ ] Stock quantity entered
- [ ] Stock status correct
- [ ] Low stock threshold set

**Categorization:**
- [ ] Primary category selected
- [ ] Subcategories added
- [ ] Relevant tags added
- [ ] Attributes set (for variable products)

**Shipping:**
- [ ] Weight entered (if physical)
- [ ] Dimensions entered
- [ ] Shipping class assigned
- [ ] Digital product flag (if applicable)

**SEO:**
- [ ] Meta title optimized
- [ ] Meta description written
- [ ] URL slug clean
- [ ] Schema markup (if custom site)

**Legal:**
- [ ] Warranty information
- [ ] Return policy link
- [ ] Terms & conditions
- [ ] Age restrictions (if applicable)

---

## Integration with Other Skills

Receives input from:
- **requirements-analyst**: Product categories, target audience
- **frontend-builder**: Platform-specific requirements

Works with:
- **design-consultant**: Product image specifications
- **project-workflow**: Bulk upload schedules, launch planning

---

## Malaysian Market Best Practices

### Local Trends:
- Mobile-first shoppers (optimize for mobile viewing)
- Price-sensitive market (show savings clearly)
- Trust indicators important (warranty, genuine products)
- Local payment methods essential
- Fast delivery expectations

### Competitive Pricing:
- Check Shopee, Lazada for comparable products
- Consider free shipping threshold
- Bundle deals popular
- Flash sales and vouchers effective

### Customer Reviews:
- Encourage reviews (automated follow-up emails)
- Respond to reviews (good and bad)
- Display ratings prominently
- Use reviews in marketing

---

**Remember**: Great product listings sell. Invest time in quality descriptions, professional images, and complete information. This reduces returns, increases conversions, and builds customer trust.
